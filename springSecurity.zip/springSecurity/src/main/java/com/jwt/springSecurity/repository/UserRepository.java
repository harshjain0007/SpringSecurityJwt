package com.jwt.springSecurity.repository;

import com.jwt.springSecurity.model.Role;
import com.jwt.springSecurity.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User,Long> {



    Optional<User> findByEmail(String email);
    User findByRole (Role role);

    //User saveUser(User user);

    Optional<User> getUserById(Long id);

}
