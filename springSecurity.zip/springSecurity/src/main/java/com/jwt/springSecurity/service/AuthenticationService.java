package com.jwt.springSecurity.service;

import com.jwt.springSecurity.dto.JwtAuthenticationResponse;
import com.jwt.springSecurity.dto.RefreshTokenRequest;
import com.jwt.springSecurity.dto.SignInRequest;
import com.jwt.springSecurity.dto.SignUpRequest;
import com.jwt.springSecurity.model.User;

public interface AuthenticationService {

    User signUp(SignUpRequest signUpRequest);

    JwtAuthenticationResponse signIn(SignInRequest signInRequest);

    JwtAuthenticationResponse refreshToken(RefreshTokenRequest refreshTokenRequest);


}
