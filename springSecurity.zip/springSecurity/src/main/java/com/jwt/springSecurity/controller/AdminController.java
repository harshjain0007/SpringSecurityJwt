package com.jwt.springSecurity.controller;

import com.jwt.springSecurity.model.User;
import com.jwt.springSecurity.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api/v1/admin")
@RequiredArgsConstructor
public class AdminController {


    @GetMapping("/hi")
    public String getMessage(){
        return "Hello World";
    }

//    @DeleteMapping("delete/user/{id}")
//    public void deleteUserByAdmin(@PathVariable Long id){
//        userRepository.deleteById(id);
//    }

//    @PutMapping("/update/{id}")
//    public ResponseEntity<Optional<User>> updateUser(@PathVariable Long id, @RequestBody User user){
//        Optional<User> updateUser= UserRepository.updateUse(id,user);
//        return  ResponseEntity.ok(updateUser);
//
//    }

}
