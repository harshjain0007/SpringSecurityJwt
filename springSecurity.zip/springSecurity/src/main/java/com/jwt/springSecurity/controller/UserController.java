package com.jwt.springSecurity.controller;

import com.jwt.springSecurity.model.Role;
import com.jwt.springSecurity.model.User;
import com.jwt.springSecurity.repository.UserRepository;
import com.jwt.springSecurity.service.UserService;
import com.jwt.springSecurity.service.impl.UserServiceImpl;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/user")
@RequiredArgsConstructor
public class UserController {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private UserServiceImpl userServiceImpl;

    @GetMapping("/getAll")
//    @PreAuthorize("hasRole('USER')")
    public ResponseEntity<List<User>> getUser(){
        List<User> users=userRepository.findAll();
       List<User> users1 =users.stream().filter(e-> e.getRole() == Role.USER).collect(Collectors.toList());
        return ResponseEntity.ok().body(users1);
    }
    //new curd
//    @PostMapping("/add")
//    public User addUser(@RequestBody User user){
//        return userRepository.saveUser(user);
//    }

    @GetMapping("/{id}")
    public Optional<User> getUserById(@PathVariable Long id){
        return userRepository.getUserById(id);
    }

    @DeleteMapping("/delete/{id}")
    public void deleteUser(@PathVariable Long id){
        userRepository.deleteById(id);
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<User> updateUser(@PathVariable Long id,@RequestBody User user){
        return  ResponseEntity.ok( userServiceImpl.update(id, user));

    }

}
