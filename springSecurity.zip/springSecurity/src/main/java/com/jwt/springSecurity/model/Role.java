package com.jwt.springSecurity.model;

public enum Role {

    USER,
    ADMIN
}
