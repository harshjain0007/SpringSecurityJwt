package com.jwt.springSecurity.dto;

import lombok.Data;
import org.springframework.stereotype.Component;

@Data
public class SignInRequest {

    private String email;
    private String password;

}
