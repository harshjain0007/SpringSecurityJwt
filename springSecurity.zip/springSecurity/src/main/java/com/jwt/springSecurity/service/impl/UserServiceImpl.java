package com.jwt.springSecurity.service.impl;
import com.jwt.springSecurity.model.User;
import com.jwt.springSecurity.repository.UserRepository;
import com.jwt.springSecurity.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;
    @Override
    public UserDetailsService userDetailsservice() {
        return  new UserDetailsService() {
            @Override
            public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
                return userRepository.findByEmail(username).orElseThrow(() ->new UsernameNotFoundException("User not found"));
            }
        };
    }

        public User update(Long id,User user){
            User usser= userRepository.getUserById(id).get();
            if(usser != null){
                usser.setFirstName(user.getFirstName());
                usser.setLastName(user.getLastName());
                usser.setRole(user.getRole());
                return userRepository.save(usser);
            }else {
               return userRepository.save(user);
            }

        }

}
