package com.jwt.springSecurity.controller;


import com.jwt.springSecurity.dto.JwtAuthenticationResponse;
import com.jwt.springSecurity.dto.RefreshTokenRequest;
import com.jwt.springSecurity.dto.SignInRequest;
import com.jwt.springSecurity.dto.SignUpRequest;
import com.jwt.springSecurity.model.User;
import com.jwt.springSecurity.service.AuthenticationService;
import lombok.Generated;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
public class AuthenticationController {

    private final AuthenticationService authenticationService;


    @PostMapping("/signup")
    public ResponseEntity<User> signUp(@RequestBody SignUpRequest signUpRequest){
        return ResponseEntity.ok(authenticationService.signUp(signUpRequest));
    }

    @PostMapping("/signin")
    public ResponseEntity<JwtAuthenticationResponse> signin(@RequestBody SignInRequest signInRequest){
        return ResponseEntity.ok(authenticationService.signIn(signInRequest));
    }

    @PostMapping("/refresh-token")
    public ResponseEntity<JwtAuthenticationResponse> refreshToken(@RequestBody RefreshTokenRequest refreshTokenRequest) {
        return ResponseEntity.ok(authenticationService.refreshToken(refreshTokenRequest));
    }





    @GetMapping("hello")
    public String hello(){
        return "Hi harsh";
    }

}
